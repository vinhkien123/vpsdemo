// const fs = require('fs');
// const path = require('path')
// const express = require('express');
// const app = require('../app');

// const router = express.Router();



// router.get('/', async (req, res, next) => {
//     let pageDir
//     pageDir = path.join(__dirname, `../public/index.html`)
//     if (fs.existsSync(pageDir)) {
//         return res.render('page/' + pagePu);
//     }
//     next();

// })




// module.exports = router;