var symbolList = ['BTC','ETH','WAVES','XRP','BCH','BNB','LTC','DOT','XTZ','XLM','TRX']
var coinList = []
module.exports = { symbolList, coinList }