module.exports = {
    account: [],
    phone: "",
    socket: {}
}