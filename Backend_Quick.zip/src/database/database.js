const mysql = require('mysql');

// const connect = mysql.createConnection({
// host: 'localhost',
// user: 'root',
// password: 'sseeaways',
// database: "new_schema"
// });
const connect = mysql.createConnection({
  host: 'localhost',
  user: 'admin_uquick',
  password: 'Ntaq50!1',
  database: "admin_quickwallet",
});
module.exports.connect = connect
// Q8v^7sv0