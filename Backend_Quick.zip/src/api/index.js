// var express = require('express');
// var router = express.Router();
// const validateToken = require("../sockets/functions/validation")
// /* GET users listing. */
// router.get('/createAccount', function (req, res, next) {
//     var walletsUSDT = await tronWeb.createAccount()
//     walletsUSDT.symbol = "USDT"
//     var walletsKAN = await tronWeb.createAccount()
//     walletsKAN.symbol = "KAN"
//     var walletsTRX = await tronWeb.createAccount()
//     walletsTRX.symbol = "TRX"
//     const data = [walletsUSDT,walletsKAN,walletsTRX]
//     return data
// });

// module.exports = router;
