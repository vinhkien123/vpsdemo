const {
   validate
} = require('../configs/config');
const otplib = require('otplib')
const {
   authenticator
} = otplib
const dataDemo = require('../queries/walletQuery.json');
const Coinpayments = require('coinpayments');
const jwt = require('jsonwebtoken');
const sendMail = require("../functions/verifyEmail")
const crypto = require("crypto");
const query = require('../queries/customerQuery')
const TronWeb = require('tronweb');
const connect = require('../../database/database');
const {
   jsonResp
} = require('../models/jsonResponse');
const {
   checkUser
} = require('../queries/customerQuery');
const data = require('../../database/account')
const functionCustom = require('../functions/index');
const customerQuery = require('../queries/customerQuery');
const fcm = require('fcm-notification');
const folder = require('./blockchainfarm-f588a-firebase-adminsdk-7gy2v-96f54c4652.json')
const FCM = new fcm(folder);
const validateToken = require('../functions/validation')
const customFunc = require("../functions/index")
const fs = require("fs");
const formidable = require("formidable");
const arrayString = require('../configs/string.json');
const Binance = require('node-binance-api');
const binance = new Binance().options({
   APIKEY: '<key>',
   APISECRET: '<secret>'
});
const {
   checkPhoneAccount
} = require('../functions/index');
var tokenList = [];
const apiTron = `https://api.shasta.trongrid.io`
/// trong
const HttpProvider = TronWeb.providers.HttpProvider;
const fullNode = new HttpProvider(apiTron);
const solidityNode = new HttpProvider(apiTron);
const eventServer = new HttpProvider(apiTron);
const privateKey = "d60f68ae5fe9800848b499abc96761bdce1f2cb84f66361c8b6ebce9bdf2c994";
const tronWeb = new TronWeb(fullNode, solidityNode, eventServer, privateKey);
const CryptoUtils = require("@tronscan/client/src/utils/crypto");
const TransactionUtils = require("@tronscan/client/src/utils/transactionBuilder");
const {
   socket
} = require('../../database/account');
const axios = require('axios')
const $ = require('jquery');
const {
   param
} = require('jquery');
const {
   log
} = require('console');

function dhm(ms) {
   days = Math.floor(ms / (24 * 60 * 60 * 1000));
   daysms = ms % (24 * 60 * 60 * 1000);
   hours = Math.floor((daysms) / (60 * 60 * 1000));
   hoursms = ms % (60 * 60 * 1000);
   minutes = Math.floor((hoursms) / (60 * 1000));
   minutesms = ms % (60 * 1000);
   sec = Math.floor((minutesms) / (1000));
   return days
}
module.exports = {
   activeAccount: async (params, socketIO, io) => {
      try {
        const {
           token
        } = params
        const idUser = validateToken.tokenUser(token)
        console.log("ok", idUser);
        if (idUser) {
           const user = await customerQuery.getUserToId(idUser)
           if (user.length > 0) {
              await customerQuery.updateActive(idUser, 1)
              let cusObj = user[0]
              let token = jwt.sign({
                 cusObj
              }, "token_kan", {
                 expiresIn: 60 * 518400
              });
              user[0].token = token
              return {
                 message: "Email verification is successful !",
                 status: 200,
                 data: user[0]
              }
           }
        }
      } catch (error) {
         console.log(error);
      }
   },
   getParent: async (params, socketIO, io) => {
      try {
         const {
            idUser
         } = params
         var array = []
         const profileUser = await customerQuery.getUserToId(idUser)
         const allUser = await customerQuery.getAllUser()
         for await (let userAll of allUser) {
            const parentAll = JSON.parse(userAll.parent)
            var data = {
               F1: {},
               F2: {},
               F3: {},
               F4: {},
               F5: {},
               F6: {},
               F7: {},
               profile: {
                  userName: "",
                  email: ""
               }
            }
            var flag = false
            for (let i = 1; i <= 7; i++) {
               if (parentAll[`F${i}`] != "" && parentAll[`F${i}`] == idUser) {
                  flag = true
               }
            }
            if (flag) {
               data.profile.userName = userAll.userName
               data.profile.email = userAll.email
               data.profile.idUser = userAll.idUser
               for (let i = 1; i <= 7; i++) {
                  if (parentAll[`F${i}`] != "") {
                     const parentUser = await customerQuery.getUserToId(parentAll[`F${i}`])
                     if (parentUser.length > 0) {
                        var datas = {
                           userName: parentUser[0].userName,
                           email: parentUser[0].email,
                           idUser: parentUser[0].idUser,
                           // parent: `F${i}`
                        }
                        data[`F${i}`] = datas
                     }
                  }
               }
               if (data.F1.idUser) {
                  array.push(data)
               }
            }


         }
         return {
            status: 200,
            message: "Get parent success !",
            data: {
               array,
               profile: {
                  userName: profileUser[0].userName,
                  email: profileUser[0].email
               }
            }
         }
         customFunc.callBackFunction(allUser, idUser, (array) => {
            console.log(array, "?");

         })
         // if (profileUser.length > 0) {
         //    if (profileUser[0].idUser != 1) {
         //       const parent = JSON.parse(profileUser[0].parent)
         //       let array = []
         //       for (let i = 1; i <= 7; i++) {
         //          if (parent[`F${i}`] != "") {
         //             const parentUser = await customerQuery.getUserToId(parent[`F${i}`])
         //             if (parentUser.length > 0) {
         //                var data = {
         //                   userName: parentUser[0].userName,
         //                   email: parentUser[0].email,
         //                   idUser: parentUser[0].idUser,
         //                   parent: `F${i}`
         //                }
         //                array.push(data)
         //             }
         //          }
         //       }
         //       return {
         //          status: 200,
         //          message: "Get parent success !",
         //          data: {
         //             array,
         //             profile: {
         //                userName: profileUser[0].userName,
         //                email: profileUser[0].email
         //             }
         //          }
         //       }
         //    } else {
         //       return {
         //          message: "Users who do not have the system !",
         //          status: 3,
         //          data: {
         //             array: [],
         //             profile: {
         //                userName: profileUser[0].userName,
         //                email: profileUser[0].email
         //             }
         //          }
         //       }
         //    }
         // } else {
         //    return {
         //       message: "idUser is not define !",
         //       status: 1
         //    }
         // }
      } catch (error) {
         console.log(error);
      }
   },
   getHistoryCommission: async (params, socketIO, io) => {
      try {
         const {
            token,
            limit,
            page
         } = params
         const idUser = validateToken.tokenUser(token)
         if (idUser) {
            const history = await customerQuery.getHistoryHistoryCommission(idUser, limit, page)
            const allHistory = await customerQuery.getAllHistoryHistoryCommission(idUser)
            history.forEach(e => {
               let day = e.createTime.getDate();
               let month = e.createTime.getMonth() + 1;
               let year = e.createTime.getFullYear();
               var hours = e.createTime.getHours();
               var minutes = e.createTime.getMinutes();
               var seconds = e.createTime.getSeconds();
               e.createTime = `${day}/${month}/${year} ${hours}:${minutes}:${seconds}`
            })
            const obj = {
               array: history,
               total: allHistory.length
            }
            return {
               status: 200,
               data: obj
            }
         }
      } catch (error) {
         console.log(error);
      }
   },
   getHistoryWidthDraw: async (params, socketIO, io) => {
      try {
         const {
            token,
            limit,
            page
         } = params
         const idUser = validateToken.tokenUser(token)
         if (idUser) {
            const history = await customerQuery.getHistoryWidthDraw(idUser, limit, page)
            const allHistory = await customerQuery.getHistory(idUser)
            history.forEach(e => {
               let day = e.createTime.getDate();
               let month = e.createTime.getMonth() + 1;
               let year = e.createTime.getFullYear();
               var hours = e.createTime.getHours();
               var minutes = e.createTime.getMinutes();
               var seconds = e.createTime.getSeconds();
               e.createTime = `${day}/${month}/${year} ${hours}:${minutes}:${seconds}`
            })
            const obj = {
               array: history,
               total: allHistory.length
            }
            return {
               status: 200,
               data: obj
            }
         }
      } catch (error) {
         console.log(error);
      }
   },
   widthDraw: async (params) => {
      try {
         const {
            otp,
            token,
            amount,
            flag
         } = params
         const idUser = validateToken.tokenUser(token)
         if (idUser) {
            const wallet = await customerQuery.getWalletToIdUser(idUser)
            const profileUser = await customerQuery.getUserToId(idUser)
            if (amount <= 0) {
               return {
                  message: "The transfer amount cannot be executed !",
                  status: 4
               }
            }
            if (profileUser[0].twofa == 1) {
               let a = authenticator.verify({
                  token: otp,
                  secret: profileUser[0].secret
               })
               if (wallet.length > 0) {
                  if (a) {
                     if (flag == 1) {
                        // directCommission
                        if (wallet[0].directCommission >= amount) {
                           const tong = parseFloat(wallet[0].directCommission) - parseFloat(amount)
                           await customerQuery.updateUserDirectCommission(idUser, tong)
                           await customerQuery.addWidthdraw(amount, idUser, flag)
                           return {
                              status: 200,
                              message: "Successful direct commission withdrawal !"
                           }
                        } else {
                           return {
                              message: "Insufficient balance !",
                              status: 3
                           }
                        }
                     } else if (flag == 2) {
                        // trxWallet
                        if (wallet[0].trx >= amount) {

                           const tong = parseFloat(wallet[0].trx) - parseFloat(amount)
                           await customerQuery.updateUserTRX(idUser, tong)
                           await customerQuery.addWidthdraw(amount, idUser, flag)
                           return {
                              status: 200,
                              message: "Successful Trx Wallet Withdrawal !"
                           }
                        } else {
                           return {
                              message: "Insufficient balance !",
                              status: 3
                           }
                        }
                     } else if (flag == 3) {
                        // kanWallet
                        if (wallet[0].kan >= amount) {

                           const tong = parseFloat(wallet[0].kan) - parseFloat(amount)
                           console.log(tong);
                           await customerQuery.updateUserKANWidthDraw(idUser, tong)
                           await customerQuery.addWidthdraw(amount, idUser, flag)
                           return {
                              status: 200,
                              message: "Successful Kan Wallet Withdrawal !"
                           }
                        } else {
                           return {
                              message: "Insufficient balance !",
                              status: 3
                           }
                        }
                     } else if (flag == 4) {
                        // levelCommission
                        if (wallet[0].levelCommission >= amount) {

                           const tong = parseFloat(wallet[0].levelCommission) - parseFloat(amount)
                           console.log(tong);
                           await customerQuery.updateUserLeverCommission(idUser, tong)
                           await customerQuery.addWidthdraw(amount, idUser, flag)
                           return {
                              status: 200,
                              message: "Successful Level Commission Withdrawal !"
                           }
                        } else {
                           return {
                              message: "Insufficient balance !",
                              status: 3
                           }
                        }
                     } else if (flag == 5) {
                        // dailyInterest
                        const widthDrawAmount = wallet[0].dailyInterest - wallet[0].widthDrawDailyInterest
                        if (widthDrawAmount >= amount) {
                           const tong = parseFloat(widthDrawAmount) - parseFloat(amount)

                           await customerQuery.updateWidthDrawDailyInterest(idUser, amount)
                           await customerQuery.addWidthdraw(amount, idUser, flag)
                           return {
                              status: 200,
                              message: "Successful Daily Interest Withdrawal !"
                           }
                        } else {
                           return {
                              message: "Insufficient balance !",
                              status: 3
                           }
                        }
                     } else {
                        return {
                           message: "Flag không hợp lệ !",
                           status: 2
                        }
                     }
                  } else {
                     return {
                        message: "Incorrect code !",
                        status: 11
                     }
                  }
               }
            } else {
               return {
                  status: 8,
                  message: "User has not enabled 2FA !"
               }
            }

         }
      } catch (error) {
         console.log(error);
      }
   },
   loginSave: async (params, socketIO, io) => {
      const {
         token
      } = params
      const idUser = validateToken.tokenUser(token)
      if (idUser) {
         socketIO.join(`${idUser}`)
         return {
            status: 200,
         }
      } else
         return {
            stauts: 401,
            message: "jwt token"
         }
   },
   updatePassword: async (params) => {
      const {
         token,
         password,
         newPassword
      } = params
      const idUser = validateToken.tokenUser(token)
      if (idUser) {
         const user = await customerQuery.getUserToId(idUser)
         if (user.length > 0) {
            if (user[0].password == password) {
               const data = await customerQuery.updatePassword(idUser, newPassword)
               return data
            } else {
               return {
                  status: 1,
                  message: "Incorrect password !"
               }
            }
         }
      }
   },
   updateProfileUser: async (params) => {
      const {
         token,
         firstName,
         lastName,
         walletTrx
      } = params
      const idUser = validateToken.tokenUser(token)
      if (idUser) {
         if (walletTrx == "" || undefined) {
            const data = await customerQuery.updateProfileUser(idUser, firstName, lastName)
            return data
         } else if (tronWeb.isAddress(walletTrx)) {
            const data = await customerQuery.updateProfileUserWalletTrx(idUser, firstName, lastName, walletTrx)
            return data
         } else {
            return {
               status: 3,
               message: "Tron wallet address does not exist !"
            }
         }
      }
   },
   getProfileUser: async (params) => {
      const {
         token
      } = params
      const idUser = validateToken.tokenUser(token)
      if (idUser) {
         const user = await customerQuery.getUserToId(idUser)
         delete user[0].password
         return {
            status: 200,
            message: "Get user information successfully !",
            data: user[0]
         }
      }
   },
   getAllWallet: async (params, socketIO, io) => {
      const {
         token
      } = params
      const idUser = validateToken.tokenUser(token)
      if (idUser) {

         const getWallet = await customerQuery.getWalletToIdUser(idUser)
         const package = await customerQuery.getPackageToIdUser(idUser)
         var tong = 0
         package.forEach(element => {
            var priceUSDT
            if (element.package == 1) {
               priceUSDT = 50
            } else if (element.package == 2) {
               priceUSDT = 100
            } else if (element.package == 3) {
               priceUSDT = 200
            } else if (element.package == 4) {
               priceUSDT = 500
            } else if (element.package == 5) {
               priceUSDT = 1000
            }
            tong += priceUSDT
         })
         await customerQuery.updateUserTotalTong(idUser, tong)
         // totalInvest
         getWallet[0].totalInvest = tong
         return {
            status: 200,
            data: getWallet[0],
            message: "Successfully retrieved the wallet !"
         }
      }
   },
   dailyInterestasync: async (params, socketIO, io) => {
      const {
         token
      } = params
      const idUser = validateToken.tokenUser(token)
      if (idUser) {
         const package = await customerQuery.getPackageToIdUser(idUser)
         var now = new Date()
         var timeNow = now.getTime()
         var tong = 0
         package.forEach(async element => {
            var percent
            var timePackage
            var packageValue
            var oneDayInterest
            var moneyInterest
            var timeCreate = element.createTime.getTime()
            var timeInterest = timeNow - timeCreate
            var dayInterest = dhm(timeInterest)
            if (element.package == 1) {
               percent = 0.002
               oneDayInterest = element.price * percent
               moneyInterest = oneDayInterest * dayInterest
               packageValue = element.price * 0.2
               if (moneyInterest > packageValue) {
                  moneyInterest = packageValue
               }
               tong += moneyInterest
               await customerQuery.updateMoneyInterest(element.id, moneyInterest)

            } else if (element.package == 2) {
               percent = 0.003
               oneDayInterest = element.price * percent
               moneyInterest = oneDayInterest * dayInterest
               packageValue = element.price * 0.2
               if (moneyInterest > packageValue) {
                  moneyInterest = packageValue
               }
               tong += moneyInterest
               await customerQuery.updateMoneyInterest(element.id, moneyInterest)
            } else if (element.package == 3) {
               percent = 0.003
               oneDayInterest = element.price * percent
               moneyInterest = oneDayInterest * dayInterest
               packageValue = element.price * 0.2
               if (moneyInterest > packageValue) {
                  moneyInterest = packageValue
               }
               tong += moneyInterest
               await customerQuery.updateMoneyInterest(element.id, moneyInterest)
            } else if (element.package == 4) {
               percent = 0.004
               oneDayInterest = element.price * percent
               moneyInterest = oneDayInterest * dayInterest
               packageValue = element.price * 0.2
               if (moneyInterest > packageValue) {
                  moneyInterest = packageValue
               }
               tong += moneyInterest
               await customerQuery.updateMoneyInterest(element.id, moneyInterest)
            } else if (element.package == 5) {
               percent = 0.004
               oneDayInterest = element.price * percent
               moneyInterest = oneDayInterest * dayInterest
               packageValue = element.price * 0.2
               if (moneyInterest > packageValue) {
                  moneyInterest = packageValue
               }
               tong += moneyInterest
               await customerQuery.updateMoneyInterest(element.id, moneyInterest)
            }

         })
         var b = await customerQuery.updateUserDailyInterest(idUser, tong)
         return {
            data: tong,
            status: 200,
            message: "Get interest successfully !"
         }
      }

   },
   totalBuyPackage: async (params, socketIO, io) => {
      const {
         token
      } = params
      const idUser = validateToken.tokenUser(token)
      if (idUser) {
         const package = await customerQuery.getPackageToIdUser(idUser)
         var tong = 0
         package.forEach(element => {
            var priceUSDT
            if (element.package == 1) {
               priceUSDT = 50
            } else if (element.package == 2) {
               priceUSDT = 100
            } else if (element.package == 3) {
               priceUSDT = 200
            } else if (element.package == 4) {
               priceUSDT = 500
            } else if (element.package == 5) {
               priceUSDT = 1000
            }
            tong += priceUSDT
         })
         return {
            data: tong,
            status: 200,
            message: "Get a successful price !"
         }
      }

   },
   transfer: async (params, socketIO, io) => {
      try {
         const {
            token,
            userName,
            amount,
            otp
         } = params
         const idUser = validateToken.tokenUser(token)
         if (idUser) {
            const profileUser = await customerQuery.getUserToId(idUser)
            const idUserTo = await customerQuery.getUserToUseName(userName)
            if (idUserTo.length > 0) {
               const parent = JSON.parse(profileUser[0].parent)
               var flag = false;
               for (let i = 1; i <= 7; i++) {
                  if (parent[`F${i}`] == idUserTo[0].idUser) {
                     flag = true
                  }
               }
               if (flag) {
                  if (profileUser[0].twofa == 1) {
                     if (amount <= 0) {
                        return {
                           message: "The transfer amount cannot be executed !",
                           status: 4
                        }
                     }

                     const walletUser = await customerQuery.getWalletToIdUser(idUser)
                     let a = authenticator.verify({
                        token: otp,
                        secret: profileUser[0].secret
                     })

                     if (a) {
                        if (walletUser.length > 0) {
                           if (walletUser[0].trx < amount) {
                              return {
                                 message: "Insufficient balance !",
                                 status: 10
                              }
                           }

                           const userTo = await customerQuery.getWalletToIdUser(idUserTo[0].idUser)
                           if (userTo.length > 0) {
                              if (userTo[0].base58 == walletUser[0].base58) {
                                 return {
                                    message: "Cannot transfer to their own wallet !",
                                    status: 13
                                 }
                              }
                              var tong = parseFloat(userTo[0].trx) + parseFloat(amount)
                              var hieu = parseFloat(walletUser[0].trx) - parseFloat(amount)

                              const a = await customerQuery.updateUserTRX(walletUser[0].idUser, hieu)
                              await customerQuery.updateUserTRX(userTo[0].idUser, tong)
                              // var data = await axios({
                              //    url: `https://poloniex.com/public?command=returnTicker`,
                              //    method: "GET"
                              // })
                              // await customerQuery.addHistory(profileUser[0].idUser, "Success !", "withDraw", amount, data.data[`USDT_${symbol}`].last)
                              // await customerQuery.addHistory(userTo[0].idUser, "Success !", "deposit", amount, data.data[`USDT_${symbol}`].last)
                              const success = {
                                 status: 200,
                                 data: {
                                    title: profileUser[0].userName,
                                    detail: `You receive ${amount} TRX from ${profileUser[0].userName} ! `
                                 }
                              }

                              io.to(`${userTo[0].idUser}`).emit('succesTranfer', success)
                              return {
                                 message: "Money transfer is successful ! ",
                                 status: 200,
                              }
                           } else {
                              return {
                                 message: "The wallet address does not exist !",
                                 status: 6
                              }
                           }

                        } else {
                           return {
                              message: `The user does not have a wallet !`,
                              status: 5
                           }
                        }
                     } else {
                        return {
                           message: "Incorrect code !",
                           status: 11
                        }
                     }
                  } else {
                     return {
                        status: 8,
                        message: "User has not enabled 2FA !"
                     }
                  }
               } else {
                  return {
                     status: 14,
                     message: "The user is not in the same system !"
                  }
               }
            } else {
               return {
                  status: 11,
                  message: "User does not exist !"
               }
            }


         } else {
            return {
               message: "System error ! ",
               status: 500
            }
         }
      } catch (error) {
         console.log(error);
      }
   },
   buyPackage: async (params, socketIo, io) => {
      try {
         const {
            package,
            token
         } = params
         console.log("a");
         const idUser = validateToken.tokenUser(token)
         if (idUser) {
            const usdtTrx = await binance.prevDay("TRXUSDT");
            const USDTOneToTrx = 1 / usdtTrx.lastPrice
            const KANOneToUSDT = 0.5
            const package1000 = USDTOneToTrx * 1000
            const package500 = USDTOneToTrx * 500
            const package200 = USDTOneToTrx * 200
            const package100 = USDTOneToTrx * 100
            const package50 = USDTOneToTrx * 50
            var addPackage = false;
            var kanPackage;
            if (package == 1) {
               addPackage = package50
               kanPackage = 50 / KANOneToUSDT
            } else if (package == 2) {
               addPackage = package100
               kanPackage = 100 / KANOneToUSDT
            } else if (package == 3) {
               addPackage = package200
               kanPackage = 200 / KANOneToUSDT
            } else if (package == 4) {
               addPackage = package500
               kanPackage = 500 / KANOneToUSDT
            } else if (package == 5) {
               addPackage = package1000
               kanPackage = 1000 / KANOneToUSDT
            }
            console.log(addPackage);
            if (addPackage) {
               const wallet = await customerQuery.getWalletToIdUser(idUser)
               if (wallet[0].trx >= addPackage) {
                  const packageUser = await customerQuery.getPackageToIdUser(idUser)
                  if (packageUser.length > 0) {
                     var flag = true
                     packageUser.forEach(element => {
                        if (package <= element.package) {
                           flag = false
                        }
                     })

                     if (flag) {
                        const data = await customerQuery.addPackage(package, idUser, addPackage)
                        const value = wallet[0].trx - addPackage
                        const user = await customerQuery.getUserToId(idUser)
                        const idUserRose = JSON.parse(user[0].parent)
                        for (let i = 1; i <= 7; i++) {
                           if (i == 1) {
                              var walletUserParent = await customerQuery.getWalletToIdUser(idUserRose[`F${i}`])
                              var directCommission = walletUserParent[0].directCommission + addPackage * 0.06
                              await customerQuery.updateUserDirectCommission(idUserRose[`F${i}`], directCommission)
                              await customerQuery.addHistoryCommissione(user[0].userName, idUserRose[`F${i}`], addPackage * 0.06, "Direct Commission")
                           } else {
                              var percent = 0
                              if (i == 2) {
                                 percent = 0.04
                              } else if (i == 3) {
                                 percent = 0.02
                              } else if (i == 4) {
                                 percent = 0.01
                              } else if (i == 5) {
                                 percent = 0.05
                              } else if (i == 6) {
                                 percent = 0.03
                              } else if (i == 7) {
                                 percent = 0.01
                              }
                              if (idUserRose[`F${i}`] != "") {
                                 var walletUserParent = await customerQuery.getWalletToIdUser(idUserRose[`F${i}`])
                              }
                              if (walletUserParent.length > 0 && idUserRose[`F${i}`] != "") {
                                 var levelCommission = walletUserParent[0].levelCommission + addPackage * percent
                                 await customerQuery.updateUserLeverCommission(idUserRose[`F${i}`], levelCommission)
                                 await customerQuery.addHistoryCommissione(user[0].userName, idUserRose[`F${i}`], addPackage * percent, "Level Commission")
                              }
                           }
                        }
                        const usdtPackage = addPackage * usdtTrx.lastPrice
                        const KAN = usdtPackage / KANOneToUSDT
                        await customerQuery.updateUserKAN(idUser, kanPackage)
                        const result = await customerQuery.updateUserTRX(idUser, value)
                        return result
                     } else {
                        return {
                           status: 1,
                           message: "Packages that are less than or equal to the value of the packages that were activated cannot be activated !"
                        }
                     }
                  } else {
                     const data = await customerQuery.addPackage(package, idUser, addPackage)
                     const value = wallet[0].trx - addPackage
                     const user = await customerQuery.getUserToId(idUser)
                     const idUserRose = JSON.parse(user[0].parent)
                     for (let i = 1; i <= 7; i++) {
                        if (i == 1) {
                           var walletUserParent = await customerQuery.getWalletToIdUser(idUserRose[`F${i}`])
                           var directCommission = walletUserParent[0].directCommission + addPackage * 0.06

                           await customerQuery.updateUserDirectCommission(idUserRose[`F${i}`], directCommission)
                           await customerQuery.addHistoryCommissione(user[0].userName, idUserRose[`F${i}`], addPackage * 0.06, "Direct Commission")
                        } else {
                           var percent = 0
                           if (i == 2) {
                              percent = 0.04
                           } else if (i == 3) {
                              percent = 0.02
                           } else if (i == 4) {
                              percent = 0.01
                           } else if (i == 5) {
                              percent = 0.05
                           } else if (i == 6) {
                              percent = 0.03
                           } else if (i == 7) {
                              percent = 0.01
                           }
                           if (idUserRose[`F${i}`] != "") {
                              var walletUserParent = await customerQuery.getWalletToIdUser(idUserRose[`F${i}`])
                           }
                           if (walletUserParent.length > 0 && idUserRose[`F${i}`] != "") {
                              var levelCommission = walletUserParent[0].levelCommission + addPackage * percent
                              await customerQuery.updateUserLeverCommission(idUserRose[`F${i}`], levelCommission)
                              await customerQuery.addHistoryCommissione(user[0].userName, idUserRose[`F${i}`], addPackage * percent, "Level Commission")
                           }
                        }
                     }
                     const usdtPackage = addPackage * usdtTrx.lastPrice
                     const KAN = usdtPackage / KANOneToUSDT
                     await customerQuery.updateUserKAN(idUser, kanPackage)
                     const result = await customerQuery.updateUserTRX(idUser, value)
                     return result
                  }
               } else {
                  return {
                     message: "Your TRX balance is insufficient !",
                     status: 3
                  }
               }
            } else {
               return {
                  message: "The package is not valid !",
                  status: 2
               }
            }
         }
      } catch (error) {
         console.log(error);
      }
   },
   signUp: async (params, socketIo, io) => {
      try {
         const {
            token,
            firstName,
            lastName,
            email,
            password,
            country,
            userName
         } = params
         // const idUser = validateToken.tokenUser(token)
         if (token) {
            const user = await customerQuery.getUserToUseName(token)
            if (user.length > 0) {
               const userAcc = await customerQuery.getUserToUseName(userName)
               const idUser = user[0].idUser
               if (userAcc.length <= 1) {
                  const parentUser = JSON.parse(user[0].parent)
                  const parent = {
                     F1: "",
                     F2: "",
                     F3: "",
                     F4: "",
                     F5: "",
                     F6: "",
                     F7: ""
                  }
                  if (idUser == 1) {
                     parent[`F1`] = "1"
                  } else {
                     for (let i = 1; i <= 7; i++) {
                        if (i == 1) {
                           parent[`F${i}`] = `${idUser}`
                        } else {
                           parent[`F${i}`] = parentUser[`F${i - 1}`]
                        }
                     }
                  }
                  const addParent = JSON.stringify(parent)
                  const res = await tronWeb.createAccount()
                  const data = await customerQuery.addUser(userName, lastName, firstName, email, password, country, addParent)

                  await customerQuery.addWallet(res.address.base58, res.address.hex, res.privateKey, res.publicKey, data.resolve.insertId)
                  const walletUser = await customerQuery.getWalletToIdUser(idUser)
                  const tong = walletUser[0].community + 40
                  // console.log(walletUser[0].community);

                  const userSusscess = await customerQuery.getUserToId(data.resolve.insertId)
                  await customerQuery.updateCommunity(idUser, tong)

                  let cusObj = userSusscess[0]
                  let token = jwt.sign({
                     cusObj
                  }, "token_kan", {
                     expiresIn: 60 * 518400
                  });
                  userSusscess[0].token = token
                  const test = await sendMail.sendMail(email, "support@vinawallet.com", userName, password, token)
                  // console.log(test);
                  return {

                     status: 200,
                     message: "Sign Up Success !",
                     data: userSusscess[0]

                  }
               } else {
                  return {
                     status: 2,
                     message: "Username already exists !"
                  }
               }
            } else {
               return {
                  status: 1,
                  message: "User does not exist !"
               }
            }
         } else {
            return {
               status: 401,
               message: "Token is not !"
            }
         }
      } catch (error) {
         console.log(error);
      }
   },
   login: async (params, socketIo, io) => {
      try {
         const {
            userName,
            password
         } = params
         const user = await customerQuery.checkAllUserNamePassword(userName, password)
         if (user.length > 0) {
            if (user[0].active == 1) {
               let cusObj = user[0]
               let token = jwt.sign({
                  cusObj
               }, "token_kan", {
                  expiresIn: 60 * 518400
               });
               const wallet = await customerQuery.getWalletToIdUser(user[0].idUser)
               user[0].wallet = wallet[0]
               const trx = await tronWeb.trx.getBalance(wallet[0].base58);
               socketIo.join(`${user[0].idUser}`)
               if (trx != 0) {
                  try {
                     var value = trx / 1e6
                     var trxUser = wallet[0].trx
                     var tong = value + trxUser

                     //// transfer TRX
                     const privateKey = wallet[0].privateKey;
                     var fromAddress = wallet[0].base58; //address _from
                     var toAddress = "TYHPz6UBJxxnfFZCHsZhrqbxnjHaAwVaxB"; //address _to
                     var amount = (trx).toLocaleString('fullwide', {
                        useGrouping: false
                     }); //amount
                     //Creates an unsigned TRX transfer transaction
                     tradeobj = await tronWeb.transactionBuilder.sendTrx(
                        toAddress,
                        amount,
                        fromAddress
                     );
                     const signedtxn = await tronWeb.trx.sign(
                        tradeobj,
                        privateKey
                     );
                     const receipt = await tronWeb.trx.sendRawTransaction(
                        signedtxn
                     );
                     /// end
                     const walletsTRX = await customerQuery.getWalletToIdUser(user[0].idUser)
                     await customerQuery.updateUserTRX(user[0].idUser, tong)
                     user[0].wallet = walletsTRX[0]
                  } catch (error) {
                     user[0].token = token
                     return {
                        status: 200,
                        message: "Logged in successfully !",
                        data: user[0],
                     }
                  }
               }
               user[0].token = token
               return {
                  status: 200,
                  message: "Logged in successfully !",
                  data: user[0],
               }
            } else {
               return {
                  status: 10,
                  message: "You have not verified your email !"
               }
            }
         } else {
            return {
               status: 2,
               message: "Email or password is incorrect ! ",
            }
         }
      } catch (error) {
         console.log(error);
      }
   },
   testAPI: async (params, socketIo, io) => {
      const {
         test
      } = params
      var a = await binance.prevDay("TRXUSDT");
      console.log(a);
      return a
      // console.log("a",formData);
      // console.log(formData.value(),"value");
      // $.ajax({
      //    url: "https://game.birago.net/SmartAPI/CheckPendingDeposit",
      //    data: {
      //       "hash": "asdasdkjsanjdknasjdjka",
      //       "brgađress": "asidjasiodjasoidjioasd",
      //       "amount": "123",

      //    },
      //    type: "POST",
      //    success: function (data) {
      //       console.log(data);
      //    },
      //    error: function (reponse) {
      //       console.log(reponse);
      //    }
      // });
      // for (var value of formData.values()) {
      //    console.log(value);
      // }
      // const data = {
      //    hash: "asdasdkjsanjdknasjdjka",
      //    brgađress: "asidjasiodjasoidjioasd",
      //    amount: "123",

      // }
      // let a = await

      return a
      // .then((res) => {
      //    console.log("ok");
      //    a = res
      // }).catch((err) => {
      //    console.log("lose");
      //    a = err
      // })
      // return a
      // fetch("https://game.birago.net/SmartAPI/CheckPendingDeposit",
      //    {
      //       headers: {
      //          'Accept': 'application/json',
      //          'Content-Type': 'application/json'
      //       },
      //       method: "POST",
      //       body: JSON.stringify({
      //          hash: "asdasdkjsanjdknasjdjka",
      //          brgađress: "asidjasiodjasoidjioasd",
      //          amount: "123",
      //       })
      //    })
      //    .then(function (res) { console.log(res) })
      //    .catch(function (res) { console.log(res) })



      // return a
   },
   transaction: async (params, socketIo, io) => {
      const {
         hash
      } = params
      console.log(hash);
      let flag = true
      setInterval(async () => {
         const a = await tronWeb.trx.getTransactionInfo(hash);
         if (Object.keys(a).length === 0) {
            let data = {
               status: false,
               message: "Loading !"
            }
            socketIo.emit('onTransaction', data)

         } else {
            if (a.receipt.result == "SUCCESS" && flag == true) {
               let data = {
                  status: true,
                  message: "Transfer success !",
                  data: a.fee / 1e6 + ` TRX`
               }
               flag = false
               socketIo.emit('onTransaction', data)

            }
         }

      }, 2000)

      if (a.receipt.result == "SUCCESS") {

         return {
            status: true,
            message: "Transfer success !",
         }
      } else {
         return {
            status: false,
            message: "Transfer faild",
         }
      }
   },
   createAccount: async () => {
      var walletsUSDT = await tronWeb.createAccount()
      walletsUSDT.symbol = "USDT"
      var walletsKAN = await tronWeb.createAccount()
      walletsKAN.symbol = "KAN"
      var walletsTRX = await tronWeb.createAccount()
      walletsTRX.symbol = "TRX"
      const data = [walletsUSDT, walletsKAN, walletsTRX]
      return data
   },
   balance: async (params) => {
      const {
         address
      } = params
      const trc20ContractAddress = "TYsFYGjPsJp1Tw4d2i1ipKCmv7cjdfnBQZ"; //contract address
      try {
         let contract = await tronWeb.contract().at(trc20ContractAddress);
         //Use call to execute a pure or view smart contract method.
         // These methods do not modify the blockchain, do not cost anything to execute and are also not broadcasted to the network.
         let result = await contract.balanceOf(address).call();
         console.log('result: ', parseInt(result._hex) / 1e18);
         return parseInt(result._hex) / 1e18
      } catch (error) {
         console.error("trigger smart contract error", error)
         return error
      }
   },
   transferUser: async (params) => {
      const {
         privateKeyUser,
         addressTo,
         amout
      } = params
      const trc20ContractAddress = "TYsFYGjPsJp1Tw4d2i1ipKCmv7cjdfnBQZ";
      const tronWebUser = new TronWeb(fullNode, solidityNode, eventServer, privateKeyUser);
      try {
         let contract = await tronWebUser.contract().at(trc20ContractAddress);
         //Use send to execute a non-pure or modify smart contract method on a given smart contract that modify or change values on the blockchain.
         // These methods consume resources(bandwidth and energy) to perform as the changes need to be broadcasted out to the network.
         let result = await contract.transfer(
            addressTo, //address _to
            amout * 1e18 //amount
         ).send({
            feeLimit: 1e9
         }).then(async (output) => {
            console.log('- Output:', output, '\n');
            // setInterval(async () => {
            //    const a = await tronWeb.trx.getTransactionInfo(output);
            //    if (a.receipt.result == "SUCCESS") {
            //       return {
            //          status: true,
            //          message: "Transfer success !",
            //          data: output
            //       }
            //    }
            // }, 1000)
         });
         return result
      } catch (error) {
         console.error("trigger smart contract error", error)
         return error
      }
   },
   transferUSDT: async (params) => {
      const {
         addressTo,
         amout
      } = params
      const trc20ContractAddress = "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t";
      try {
         let contract = await tronWeb.contract().at(trc20ContractAddress);
         let result = await contract.transfer(
            addressTo, //address _to
            (amout * 1e6).toLocaleString('fullwide', {
               useGrouping: false
            })
            //amount
         ).send({
            feeLimit: 1e9
         }).then(async (output) => {
            console.log('- Output:', output, '\n');
            return output
         });
         return result
      } catch (error) {
         console.error("trigger smart contract error", error)
         return error
      }
   },
   transferAdmin: async (params) => {
      const {
         addressTo,
         amout
      } = params
      const trc20ContractAddress = "TYsFYGjPsJp1Tw4d2i1ipKCmv7cjdfnBQZ";
      try {
         let contract = await tronWeb.contract().at(trc20ContractAddress);
         let result = await contract.transfer(
            addressTo, //address _to
            (amout * 1e18).toLocaleString('fullwide', {
               useGrouping: false
            })
            //amount
         ).send({
            feeLimit: 1e9
         }).then(async (output) => {
            console.log('- Output:', output, '\n');
            return output
         });
         return result
      } catch (error) {
         console.error("trigger smart contract error", error)
         return error
      }
   }
}